<?php

class MenuFamily
{
	public $all = [];
	public $parent;
	public $parent_siblings = [];
	
	public $current_page;
	public $siblings = [];
	public $children = [];
}