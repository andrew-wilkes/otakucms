<?php

class ErrorPage
{
	public $title = "Page not found";
	public $template = "error404";
	public $content = "Error: Page not found!";
	public $live = true;
	public $id = 0;
	public $key = '';
}