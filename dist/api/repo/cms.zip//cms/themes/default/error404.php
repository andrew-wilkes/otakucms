<?php
Tokens::add(['#TITLE#' => Page::get_value('title')]);
include 'header.php';
?>

<div class="column">
<?php Page::display_content(); ?>

<div><?php //echo $widgets->insert('main'); ?></div>

</div>

<div class="column"><?php //echo $widgets->insert('sidebar'); ?></div>

<?php include 'footer.php'; ?>