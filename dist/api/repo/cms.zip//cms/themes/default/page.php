<?php
Tokens::add(['#TITLE#' => Page::get_value('title')]);

if (Session::$is_moderator)
{
  HTML::register_scripts(['content-tools.min.js', 'cloudinary.js', 'editor.js','axios.min.js','common.js']);
  HTML::script_meta_tags(['css' => ['content-tools.min.css']]); 
}

include 'header.php';
?>

<div class="content" data-editable data-name="main-content">
<?php Page::insert_region_content(); ?>
</div>

<?php include 'footer.php'; ?>