<?php

Tokens::add(['#TITLE#' => Page::get_value('title')]);

$scripts = ['vue.min.js','vee-validate.min.js','axios.min.js','common.js','contact.js'];
$css = ['comments.css','pure.min.css'];
if (Session::$is_moderator)
{
  $scripts[] = 'content-tools.min.js';
  $scripts[] = 'cloudinary.js';
  $scripts[] = 'editor.js';
  $css[] = 'content-tools.min.css'; 
}
HTML::register_scripts($scripts);
HTML::script_meta_tags(['css' => $css]);

include 'header.php';
?>

<div class="content">
  <div data-editable data-name="main-content">
    <?php Page::insert_region_content(); ?>
  </div>
	<div id="contact">
		<contact></contact>
	</div>
</div>

<?php include 'footer.php'; ?>
