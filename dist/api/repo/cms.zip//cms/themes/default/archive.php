<?php
include 'header.php';

if (Session::$is_moderator)
{
  HTML::register_scripts(['content-tools.min.js', 'cloudinary.js', 'editor.js','axios.min.js','common.js']);
  HTML::script_meta_tags(['css' => ['content-tools.min.css']]); 
}
?>

<div class="content">

<h2>#TITLE#</h2>

<div data-editable data-name="main-content">
<?php Page::insert_region_content(); ?>
</div>

<?php	Archive::get_content(); ?>

</div>

<?php include 'footer.php'; ?>
