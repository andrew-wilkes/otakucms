<?php
if (Session::$is_moderator)
{
  HTML::register_scripts(['content-tools.min.js', 'cloudinary.js', 'editor.js','axios.min.js','common.js']);
  HTML::script_meta_tags(['css' => ['content-tools.min.css']]); 
}

include 'header.php';
?>
<div class="sidebar">

<ul>
<?php
  new Menu('sidebar');
  Menu::html(['parent','siblings','children']);
?>
</ul>

<h3>Categories</h3>

<?php Categories::print_list(); ?>

<div><?php Widgets::insert('sidebar'); ?></div>

</div>

<div class="content">
<h2>#TITLE#</h2>

<div data-editable data-name="main-content">
<?php Page::insert_region_content(); ?>
</div>

<ul>	
<?php Category::list_pages(); ?>
</ul>

<div><?php Widgets::insert('main'); ?></div>

</div>

<?php include 'footer.php'; ?>